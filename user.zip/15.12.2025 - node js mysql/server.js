const express = require('express')
const cors = require('cors')
const mysql = require('mysql')
const md5 = require('md5')
const app = express()
const port = 3000
app.use(cors())

let con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "logowanie"
})

con.connect((err) => {
    if(err) {
        console.log("Nie udało się połączyć z bazą sql")
    } else {
        console.log("Udało się połączyć z bazą sql")
    }
})

app.get('/signup/:login/:password', (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    const sql = `INSERT INTO users(login, password, uprawnienia) VALUES ('${login}', '${password}', 'użytkownik')`

    con.query(sql, (err, result) => {
        if(err) {
            res.json({
                status: `err`
            })
        } else {
            res.json({
                status: `ok`
            })
        }
    })
})

app.get('/signin/:login/:password', (req, res) => {
    const login = req.params.login
    const password = md5(req.params.password)

    const sql = `SELECT * FROM users WHERE login = '${login}' AND password = '${password}'`

    con.query(sql, (err, result) => {
            if(err) {
                res.json({
                    status: `err`
                })
            } else {
                if(result.length == 0) {
                    res.json({
                    status: `err`
                })
                } else {
                    res.json({
                    status: `Zalogowano`,
                    login: `${result[0].login}`,
                    uprawnienia: `${result[0].uprawnienia}`
                })
            }
        }
    })
})

app.listen(port, () => {
    console.log("Aplikacja działa")
})