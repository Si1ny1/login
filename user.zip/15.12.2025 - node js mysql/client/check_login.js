function check() {
    const status = JSON.parse( localStorage.getItem("logowanie") )
    console.log(status)

    if(status?.status != "zalogowano") {
        window.location.href = "login.html"
    } if(status?.uprawnienia = "admin") {
        window.location.href = "pracownik.html"
    } if(status?.uprawnienia = "użytkownik") {
        window.location.href = "user.html"
    }
}

check()