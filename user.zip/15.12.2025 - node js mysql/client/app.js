async function signup() {
    const login = document.querySelector("#login_up").value
    const password = document.querySelector("#password_up").value
 
    const responsein = await fetch(`http://localhost:3000/signup/${login}/${password}`)
    const jsonup = await responsein.json()
    if (jsonup.status == "err") {
        document.querySelector("#statusup").innerHTML = "Nie zarejestrowano"
        console.log(jsonup)
    } else {
        document.querySelector("#statusup").innerHTML = "Zarejestrowano"
        login_up.value = ""
        password_up.value = ""
    }
}

async function signin() {
    const login = document.querySelector("#login_in").value
    const password = document.querySelector("#password_in").value

    const responseup = await fetch(`http://localhost:3000/signin/${login}/${password}`)
    const jsonin = await responseup.json()
    if (jsonin.status == "err") {
        document.querySelector("#statusin").innerHTML = "Nie znaleziono konta"
        console.log(jsonin)
    } else {
        document.querySelector("#statusin").innerHTML = "Zalogowano"
        localStorage.setItem("logowanie", JSON.stringify(jsonin))
        login_in.value = ""
        password_in.value = ""
    }
}